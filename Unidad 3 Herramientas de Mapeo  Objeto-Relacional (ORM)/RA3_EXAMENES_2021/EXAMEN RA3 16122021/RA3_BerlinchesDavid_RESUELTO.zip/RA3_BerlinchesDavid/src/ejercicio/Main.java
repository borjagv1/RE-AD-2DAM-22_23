package ejercicio;

import java.util.List;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.internal.build.AllowSysOut;
import org.hibernate.query.Query;

import model.*;


public class Main {
	static final SessionFactory sesion = HibernateUtil.getSessionFactory();
	//Session session = sesion.openSession();
	//Transaction tx = session.beginTransaction();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ejercicio1A(sesion);
		ejercicio1B(sesion);
		ejercicio2(sesion);
		//ejercicio3(sesion);
	}
	
	public static void ejercicio1A(SessionFactory sesion) {
		Session session = sesion.openSession();
		Transaction tx = session.beginTransaction();

		String hql1 = "select departamento.id, count(idProfesor) from Profesor group by departamento.id";
		Query q1 = session.createQuery(hql1);
		List<Object[]> lista1 = q1.list();
		
		for(Object[] array1 : lista1) {
			Departamento dep = session.load(Departamento.class, (int)array1[0]);
			dep.setNumprof(Integer.valueOf(array1[1].toString()));
			System.out.println("Departameno: " + array1[0] + "Numero de profesores: " + array1[1]) ;
			session.update(dep);
			System.out.println("Actualizado...");
		}
		tx.commit();
		System.out.println("--Commit--");
		
	}
	
	public static void ejercicio1B(SessionFactory sesion) {
		Session session = sesion.openSession();
		Transaction tx = session.beginTransaction();
		
		String hql = "select grado.id, count(id), sum(creditos) from Asignatura group by grado.id";
		Query q = session.createQuery(hql);
		List<Object[]> lista = q.list();
		for(Object[] array : lista) {
			Grado gr = session.load(Grado.class, (int)array[0]);
			gr.setNumasig(Integer.valueOf(array[1].toString()));
			int sumaCreditos = ((Double) array[2]).intValue();
			gr.setSumacreditos(sumaCreditos);
			System.out.println("Grado: " + array[0] + ", con " + array[1] + "alumnos; " + array[2] + "total creditos");
			session.update(gr);
			System.out.println("Actualizado...");
		}
		tx.commit();
		System.out.println("--Commit--");
	}
	
	public static void ejercicio2(SessionFactory sesion) {
		Session session = sesion.openSession();
		Transaction tx = session.beginTransaction();
		
		Query q = session.createQuery("from Asignatura");
		List<Asignatura> lista = q.list();
		for(Asignatura asignatura : lista) {
			ResumenAsignatura resumen = new ResumenAsignatura(asignatura, 0 , 0.0f);
			//System.out.println(resumen.getId() + resumen.getNumeroalum()+  resumen.getNotamedia());
			try {
				session.save(resumen);
			} catch (NonUniqueObjectException no) {
				ResumenAsignatura resBorrar = session.load(ResumenAsignatura.class, asignatura.getId());
				session.delete(resBorrar);
				//System.out.println("borrado");
			}
			
		}
		String hql ="select id.idAsignatura, count(id.idAlumno), avg(nota) from AlumnoSeMatriculaAsignatura  group by id.idAsignatura";
		
		Query q1 = session.createQuery(hql);
		List<Object[]> lista1 = q1.list();
		for(Object[] array : lista1) {
			
			ResumenAsignatura res = session.get(ResumenAsignatura.class, Integer.parseInt(array[0].toString()));
			if(res == null) {
				Asignatura asig = session.get(Asignatura.class, Integer.parseInt(array[0].toString()));
				ResumenAsignatura resN = new ResumenAsignatura();
				resN.setAsignatura(asig);
				resN.setId(Integer.parseInt(array[0].toString()));
				resN.setNumeroalum(Integer.parseInt(array[1].toString()));
				resN.setNotamedia(Float.valueOf(array[2].toString()));
				System.out.println("Id Asig: " + array[0] + "numeo alumnos: "+ array[1] + "nota media: " + array[2]);
				session.save(resN);
			}else {
				res.setNumeroalum(Integer.parseInt(array[1].toString()));
				res.setNotamedia(Float.valueOf(array[2].toString()));
				System.out.println("Id Asig: " + array[0] + "numeo alumnos: "+ array[1] + "nota media: " + array[2]);
				session.update(res);
			}

		}
			
		tx.commit();
		System.out.println("--commit--");
	}
	
	public static void ejercicio3(SessionFactory sesion) {
		Session session = sesion.openSession();
		Transaction tx = session.beginTransaction();
		
		Query q = session.createQuery("from Persona where tipo = 'alumno'");
		List<Persona> lista = q.list();
		for(Persona persona : lista) {
			ResumenAlumnoId resId = new ResumenAlumnoId();
			CursoEscolar curso99 = session.get(CursoEscolar.class, 99);
			ResumenAlumno resumen = new ResumenAlumno(resId, curso99, persona, 0, 0.0f);
			System.out.println(resumen.getId());
			try {
				session.save(resumen);
				System.out.println("guardado a ceros");
			} catch (NonUniqueObjectException no) {
				ResumenAlumno resBorrar = session.load(ResumenAlumno.class, resId);
				session.delete(resBorrar);
				System.out.println("borrado");
			}
			
		}
		String hql = "select id.idAlumno, id.idCursoEscolar, count(id.idAsignatura), avg(nota) from AlumnoSeMatriculaAsignatura group by id.idAlumno, id.idCursoEscolar";
		
		Query q1 = session.createQuery(hql);
		List<Object[]> lista1 = q1.list();
		for(Object[] array : lista1) {
			ResumenAlumno res = session.get(ResumenAlumno.class, Integer.parseInt(array[0].toString()));
			CursoEscolar curso = session.get(CursoEscolar.class, (int)array[1]);
			if(res == null) {
				//Asignat asig = session.get(Asignatura.class, Integer.parseInt(array[0].toString()));
				ResumenAlumno resN = new ResumenAlumno();
				res.setCursoEscolar(curso);
				res.setNumeroasig((int) array[2]);
				res.setNotamedia((float) array[3]);
				System.out.println("Id alumno: " + array[0] + "id curso escolar: "+ array[1] + "num Asig: " + array[2] +  "nota Media: " +  array[3]);
				session.save(resN);
			}else {
				
				res.setCursoEscolar(curso);
				res.setNumeroasig((int) array[2]);
				res.setNotamedia((float) array[3]);
				System.out.println("Id alumno: " + array[0] + "id curso escolar: "+ array[1] + "num Asig: " + array[2] +  "nota Media: " +  array[3]);
				session.update(res);
			}
		}
	}
}
