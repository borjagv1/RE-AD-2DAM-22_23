import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

/**
 * 
 */

/**
 * @author Borja
 *
 */
public class Main_GuerraValenciaBorja {
	static Connection conexion;
	static int contadorError;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		cabeceraEjercicio("Ejercicio 1:");
		
		ejercicio1(args);
		
		cabeceraEjercicio("Ejercicio 2:");
		
		ejercicio2(1);
		ejercicio2(1000);
		ejercicio2(4);
		ejercicio2(2);//SOLO para comprobar que se va  sumando en la columna ej 3.
		
		cabeceraEjercicio("Ejercicio 3:");
		
		ejercicio3(11, "GESTI�N", "C/Mayor 17", "Madrid", 101, 1);
		ejercicio3(111, "GESTI�N", "C/Mayor 17", "Madrid", 10, 123);
		ejercicio3(11, "GESTI�N", "C/Mayor 17", "Madrid", 10, 123);
		ejercicio3(112, "GESTI�N", "C/Mayor 17", "Madrid", 101, 1);
		ejercicio3(113, "GESTI�N", "C/Mayor 17", "Madrid", 101, 2);

	}// Main

	
	/* EJERCICIO 3 */

	private static void ejercicio3(int coddepart, String nombredepart, String direcciondep, String localidaddep,
			int codjefedep, int codempre) {

		try {
			
			conexion_MYSQL_Empresas();

			compruebaErrores(coddepart, codjefedep, codempre);
			
			if (contadorError != 0) {//Contador static para que el valor nos dure todo el procedimiento
				System.out.println("HAY ERRORES, NO SE INSERTAR� EL REGISTRO\n");
			} else {

				creaColumnaEmpresa();

				insercionDepartamentos(coddepart, nombredepart, direcciondep, localidaddep, codjefedep, codempre);

			}

			contadorError = 0;//Retornamos a 0 para el siguiente paso.

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			mensajesError(e);
		} // Catch
		try {
			conexion.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* M�TODOS EJERCICIO 3 */
	
	/**
	 * COMPROBAMOS ERRORES ANTES DE INSERTAR. SI HAY ERRORES, NO SE INSERTA NADA
	 * @param coddepart
	 * @param codjefedep
	 * @param codempre
	 * @throws SQLException
	 */
	private static void compruebaErrores(int coddepart, int codjefedep, int codempre) throws SQLException {
		if (existeCodDepar(coddepart)) {
			System.out.println("EL DEPARTAMENTO " + coddepart + ", YA EXISTE");
			contadorError++;
		} else {
		}
		//
		if (!existeJefeDepar(codjefedep)) {
			System.out.println("EL JEFE DE DEPARTAMENTO " + codjefedep + ", NO EXISTE");
			contadorError++;
		} else {
		}
		//
		if (!existeCodEmpre(codempre)) {
			System.out.println("EL C�DIGO DE EMPRESA " + codempre + " NO EXISTE");
			contadorError++;
		} else {
		}
	}
	
	/**
	 * CREAR COLUMNA ANTES DE INSERTAR
	 * @throws SQLException
	 */
	private static void creaColumnaEmpresa() throws SQLException {
		String sql = "ALTER TABLE empresas ADD IF NOT EXISTS columna INT (11) not null;";// Si ya existe, no
																							// hace nada

		Statement sentencia = conexion.createStatement();

		try {
			sentencia.executeUpdate(sql);
			// System.out.println("Registro INSERTADO......\n");
		} catch (SQLException e) {
			mensajesError(e);
		}

		sentencia.close(); // Cerrar Statement

		// FIN DE CREAR COLUMNA ANTES DE INSERTAR UNA VEZ INSERTADA LE PONEMOS +1 CADA
		// VEZ QUE SE INSERTE.
	}
	
	/**
	 * @param coddepart
	 * @param nombredepart
	 * @param direcciondep
	 * @param localidaddep
	 * @param codjefedep
	 * @param codempre
	 * @throws SQLException
	 */
	private static void insercionDepartamentos(int coddepart, String nombredepart, String direcciondep,
			String localidaddep, int codjefedep, int codempre) throws SQLException {
		String sql = "INSERT INTO departamentos VALUES(?,?,?,?,?,?)";

		PreparedStatement sentencia = conexion.prepareStatement(sql);
		sentencia.setInt(1, coddepart);
		sentencia.setString(2, nombredepart);
		sentencia.setString(3, direcciondep);
		sentencia.setString(4, localidaddep);
		sentencia.setInt(5, codjefedep);
		sentencia.setInt(6, codempre);

		try {
			sentencia.executeUpdate();
			System.out.println("Registro INSERTADO......");
		} catch (SQLException e) {
			mensajesError(e);
		}
		// FIN INSERCI�N

		// FUNCION1 PARA ACTUALIZAR EL N� DE DEPARTAMENTOS EN LA COLUMNA NUEVA CREADA.
		// INSERTAR FUNCI�N1 AQU� //FUNCION1 PARA ACTUALIZAR EL N� DE DEPARTAMENTOS EN
		// LA COLUMNA NUEVA CREADA.
		String llamaCallable = "{ ? = call FUN1_BORJAGUERRA (?) } "; // MYSQL

		// Preparamos la llamada
		CallableStatement llamada = conexion.prepareCall(llamaCallable);

		llamada.registerOutParameter(1, Types.INTEGER); // valor devuelto
		llamada.setInt(2, codempre); // param de entrada

		llamada.executeUpdate(); // ejecutar el procedimiento
		// System.out.println("\tN�mero de departamentos: " + llamada.getInt(1));
		int numeroDepartamentos = llamada.getInt(1);
		llamada.close();
		//YA TENEMOS N� DE DEPARTS
		String sql1 = "UPDATE EMPRESAS SET columna = ? WHERE codempre = ?;";//WHERE......

		PreparedStatement sentencia1 = conexion.prepareStatement(sql1);
		sentencia1.setInt(1, numeroDepartamentos);
		sentencia1.setInt(2, codempre);

		try {
			sentencia1.executeUpdate();
			System.out.println("Se ha sumado 1 a la empresa: " + codempre);
		} catch (SQLException e) {
			mensajesError(e);
		}
		// Inserci�n
		

		sentencia1.close(); // Cerrar Statement
	}

	/**
	 * @param codempre
	 * @return
	 * @throws SQLException
	 */
	private static boolean existeCodEmpre(int codempre) throws SQLException {
		String sql = "SELECT *" + "FROM empresas WHERE codempre = ?";
		PreparedStatement sentencia = conexion.prepareStatement(sql);
		sentencia.setInt(1, codempre);

		ResultSet resul = sentencia.executeQuery();

		// Recorremos el resultado para visualizar cada fila
		// Se hace un bucle mientras haya registros y se van visualizando
		if (resul.next()) {

			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param coddepart
	 * @return
	 * @throws SQLException
	 */
	private static boolean existeCodDepar(int coddepart) throws SQLException {
		String sql = "SELECT *" + "FROM departamentos WHERE coddepart = ?";
		PreparedStatement sentencia = conexion.prepareStatement(sql);
		sentencia.setInt(1, coddepart);

		ResultSet resul = sentencia.executeQuery();

		// Recorremos el resultado para visualizar cada fila
		// Se hace un bucle mientras haya registros y se van visualizando
		if (resul.next()) {
			return true;
		} else {

			return false;
		}
	}

	/**
	 * @param codjefedep
	 * @return
	 * @throws SQLException
	 */
	private static boolean existeJefeDepar(int codjefedep) throws SQLException {
		String sql = "SELECT *" + "FROM departamentos WHERE codjefedepartamento = ?";
		PreparedStatement sentencia = conexion.prepareStatement(sql);
		sentencia.setInt(1, codjefedep);

		ResultSet resul = sentencia.executeQuery();

		// Recorremos el resultado para visualizar cada fila
		// Se hace un bucle mientras haya registros y se van visualizando
		if (resul.next()) {

			return true;
		} else {
			return false;
		}
	}

	/* EJERCICIO 2 */

	/*
	 * FUNCI�N 2: BEGIN DECLARE cont INT; SELECT COUNT(E.codemple) FROM EMPLEADOS E,
	 * departamentos D WHERE E.coddepart = D.coddepart AND D.codempre =
	 * codigoEmpresa INTO cont; RETURN cont; END
	 * 
	 */

	/*
	 * FUNCI�N 1: BEGIN DECLARE cont INT; SELECT COUNT(d.coddepart) from
	 * departamentos d, empresas p where p.codempre = codigoEmpresa and d.codempre =
	 * codigoEmpresa INTO cont; RETURN cont; END
	 */

	/**
	 * LISTADO EJERCICIO2
	 * 
	 * @param codEmpre
	 */
	private static void ejercicio2(int codEmpre) {
		try {
			conexion_MYSQL_Empresas();

			if (existeEmpresa(codEmpre)) {
				String sql = "SELECT E.codempre, E.nombre, COUNT(D.coddepart) AS CONTADOR FROM EMPRESAS E, departamentos D WHERE D.codempre = ? AND E.codempre = ?;";
				PreparedStatement sentencia = conexion.prepareStatement(sql);
				sentencia.setInt(1, codEmpre);
				sentencia.setInt(2, codEmpre);
				ResultSet resul = sentencia.executeQuery();
				while (resul.next()) {
					System.out.printf("C�digo empresa: %d, Nombre: %s%n", resul.getInt(1), resul.getString(2),
							resul.getInt(3));

					// INSERTAR FUNCI�N1 AQU� //FUNCION1
					String llamaCallable = "{ ? = call FUN1_BORJAGUERRA (?) } "; // MYSQL

					// Preparamos la llamada
					CallableStatement llamada = conexion.prepareCall(llamaCallable);

					llamada.registerOutParameter(1, Types.INTEGER); // valor devuelto
					llamada.setInt(2, codEmpre); // param de entrada

					llamada.executeUpdate(); // ejecutar el procedimiento
					System.out.println("\tN�mero de departamentos: " + llamada.getInt(1));
					llamada.close();

					// INSERTAR FUNCI�N2 AQU� //FUNCION2
					String llamaCallable2 = "{ ? = call FUN2_BORJAGUERRA (?) } "; // MYSQL

					// Preparamos la llamada
					CallableStatement llamada2 = conexion.prepareCall(llamaCallable2);

					llamada2.registerOutParameter(1, Types.INTEGER); // valor devuelto
					llamada2.setInt(2, codEmpre); // param de entrada

					llamada2.executeUpdate(); // ejecutar el procedimiento
					System.out.println("\tN�mero de empleados: " + llamada2.getInt(1));
					llamada2.close();
					System.out
							.println("------------------------------------------------------------------------------");
				}

			} else {
				System.out.println("\t�Vaya! parece que no existe la empresa " + "\"" + codEmpre + "\"" + ".......");
				System.out.println("------------------------------------------------------------------------------");

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			mensajesError(e);
		} // Catch
		try {
			conexion.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/* EJERCICIO1 */

	/**
	 * LISTADO EJERCICIO1
	 * 
	 * @param args
	 */
	private static void ejercicio1(String[] args) {
		int codEmpre = 0;
		codEmpre = argsMainCorrecto(args, codEmpre);

		try {
			conexion_MYSQL_Empresas();
//			if (args.length != 0) {

			if (existeEmpresa(codEmpre)) {
				String sql = "SELECT E.codempre, E.nombre, E.direccion, COUNT(D.coddepart) AS CONTADOR FROM EMPRESAS E, departamentos D WHERE D.codempre = ? AND E.codempre = ?;";
				PreparedStatement sentencia = conexion.prepareStatement(sql);
				sentencia.setInt(1, codEmpre);
				sentencia.setInt(2, codEmpre);
				ResultSet resul = sentencia.executeQuery();
				while (resul.next()) {
					System.out.printf("COD-EMPRESA: %d\t NOMBRE: %s%nDIRECCI�N: %s\t N�MERO DE DEPARTAMENTOS: %d%n",
							resul.getInt(1), resul.getString(2), resul.getString(3), resul.getInt(4));
					System.out
							.println("------------------------------------------------------------------------------");
				}

				// Segunda consulta
				String sql2 = "SELECT d.coddepart, d.nombre, d.localidad FROM departamentos d where d.codempre = ?;";
				PreparedStatement sentencia2 = conexion.prepareStatement(sql2);
				sentencia2.setInt(1, codEmpre);

				ResultSet resul2 = sentencia2.executeQuery();
				while (resul2.next()) {
					System.out.printf("COD-DEPARTARMENTO: %d\t NOMBRE: %s\t LOCALIDAD: %s%n", resul2.getInt(1),
							resul2.getString(2), resul2.getString(3));
					System.out.println(
							"---------------------------------------------------------------------------------");

					// tercera consulta

					/*
					 * SELECT e.codemple, e.nombre, o.nombre, (SELECT NOMBRE FROM EMPLEADOS WHERE
					 * codemple = (SELECT codencargado FROM EMPLEADOS WHERE codemple = e.codemple))
					 * FROM empleados e, oficios o WHERE e.coddepart = 12 AND o.codoficio =
					 * e.codoficio;
					 */
					String sql3 = "SELECT e.codemple, e.nombre, o.nombre, "
							+ "IFNULL((SELECT NOMBRE FROM EMPLEADOS WHERE codemple = (SELECT codencargado FROM EMPLEADOS WHERE codemple = e.codemple)), '* * * * *') "
							+ "FROM empleados e, oficios o " + "WHERE e.coddepart = ? "
							+ "AND o.codoficio = e.codoficio;";
					PreparedStatement sentencia3 = conexion.prepareStatement(sql3);
					sentencia3.setInt(1, resul2.getInt(1));

					ResultSet resul3 = sentencia3.executeQuery();
					System.out.println(" COD-EMP  NOMBRE              OFICIO                    NOMBRE ENCARGADO");
					System.out.println(" -------  ------------------  ------------------------  ---------------------");
					int cont = 0;
					while (resul3.next()) {

						System.out.printf(" %7d  %-19s %-25s %s%n", resul3.getInt(1), resul3.getString(2),
								resul3.getString(3), resul3.getString(4));
						cont++;
						// System.out.println("------------------------------------------------------------------------------");
					}

					System.out
							.println("------------------------------------------------------------------------------");
					System.out.println("N� de empleados del departamento: " + cont);
					// SELECT e.nombre from empleados e, departamentos d where d.codjefedepartamento
					// = e.codemple AND D.coddepart = 12;

					String sql4 = "SELECT e.nombre from empleados e, departamentos d where d.codjefedepartamento = e.codemple AND D.coddepart = ?;\r\n";
					PreparedStatement sentencia4 = conexion.prepareStatement(sql4);
					sentencia4.setInt(1, resul2.getInt(1));

					ResultSet resul4 = sentencia4.executeQuery();
					String nombre = null;
					while (resul4.next()) {
						nombre = resul4.getString(1);
					}
					System.out.println("Nombre del jefe de departamento: " + nombre + "\n");

					resul3.close();
					sentencia3.close();
					resul4.close();
					sentencia4.close();
				}

				/* SELECT COUNT(codDEPART) FROM departamentos WHERE codempre = 1; */

				resul.close(); // Cerrar ResultSet
				resul2.close();

				sentencia.close(); // Cerrar Statement
				sentencia2.close();

			} else {
				System.out.println("\t�Vaya! parece que no existe la empresa " + "\"" + codEmpre + "\"" + ".......");

			}
//			}else {
//				System.out.println("\t\tERROR > ARGUMENTOS DE MAIN INCORRECTOS");
//				System.out.println("\t\tFin de proceso.....");
//			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			mensajesError(e);
		} // Catch
		try {
			conexion.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// Ejercicio1

	/* M�TODOS PARA EJERCICIO1 */

	/**
	 * EXISTE EMPRESA
	 * 
	 * @param codEmpre
	 * @return
	 * @throws SQLException
	 */
	private static boolean existeEmpresa(int codEmpre) throws SQLException {
		String sql = "SELECT * FROM empresas WHERE codempre = ?";
		PreparedStatement sentencia = conexion.prepareStatement(sql);
		sentencia.setInt(1, codEmpre);

		boolean existe = false;
		ResultSet resul = sentencia.executeQuery(); // Resulset para consultas de una BBDD
		if (resul.next()) {
			existe = true;
		}

		resul.close();

		return existe;
	}

	/* M�TODOS �TILES */

	/**
	 * ARGS MAIN CORRECTOS
	 * 
	 * @param args
	 * @param codEmpre
	 * @return
	 */
	private static int argsMainCorrecto(String[] args, int codEmpre) {

		while (args.length != 0) {
			try {
				codEmpre = Integer.parseInt(args[0]);

			} catch (NumberFormatException e) {
				System.out.println("ERROR > " + e);
				System.out.print("Introduce un n�mero en los argumentos de Main");

			}
			break;
		}

		return codEmpre;
	}

	/**
	 * MENSAJES ERROR TRY-CATCH
	 * 
	 * @param e
	 */
	private static void mensajesError(SQLException e) {
		if (e.getErrorCode() == 1062)
			System.out.println("CLAVE PRIMARIA DUPLICADA");
		else if (e.getErrorCode() == 1452)
			System.out.println("CLAVE AJENA NO EXISTE");

		else {
			System.out.println("HA OCURRIDO UNA EXCEPCI�N:");
			System.out.println("Mensaje:    " + e.getMessage());
			System.out.println("SQL estado: " + e.getSQLState());
			System.out.println("C�d error:  " + e.getErrorCode());
		}
	}

	/**
	 * CONEXI�N EMPRESAS
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private static void conexion_MYSQL_Empresas() throws ClassNotFoundException, SQLException {
		// MYSQL
		System.out.println("\t\tMYSQL");
		// Cargar el driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		// Establecemos la conexion con la BD
		conexion = DriverManager.getConnection("jdbc:mysql://localhost/empresas", "empresas", "empresas");
	}

	/**
	 * CABECERA ADORNO EJERCICIO
	 * @param ejercicio 
	 * 
	 */
	private static void cabeceraEjercicio(String ejercicio) {
		System.out.println("***************************************************");
		System.out.println("*****              "+ejercicio+"               *****");
		System.out.println("***************************************************");
	}


}// Class
